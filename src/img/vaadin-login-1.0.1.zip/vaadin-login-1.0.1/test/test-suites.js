window.VaadinLoginSuites = [
  'login-test.html',
  'login-form-test.html',
  'login-overlay-test.html'
];
